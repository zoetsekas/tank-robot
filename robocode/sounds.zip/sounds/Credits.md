# Credits of the sound files

### death.wav

|                  |                                                     |
|------------------|-----------------------------------------------------|
| Name             | explosion                                           |
| Source           | https://pixabay.com/sound-effects/explosion-107629/ |
| Orginal filename | explosion-107629.wav                                |
| Uploaded by      | plamdi1                                             |

### gunshot.wav

|                   |                                                          |
|-------------------|----------------------------------------------------------|
| Name              | laser gun sound                                          |
| Source            | https://pixabay.com/sound-effects/laser-gun-sound-40813/ |
| Original filename | laser_gun_sound-40813.wav                                |
| Uploaded by       | Smoker858                                                |

### bullet_hit.wav

|                   |                                                    |
|-------------------|----------------------------------------------------|
| Name              | Smoke Bomb                                         |
| Source            | https://pixabay.com/sound-effects/smoke-bomb-6761/ |
| Original filename | smoke-bomb-6761.wav                                |
| Uploaded by       | vckhaze                                            |

### wall_collision.wav

|                   |                                                   |
|-------------------|---------------------------------------------------|
| Name              | Car Door                                          |
| Source            | https://pixabay.com/sound-effects/car-door-47981/ |
| Original filename | car-door-47981.wav                                |
| Uploaded by       | amy2018                                           |

### bots_collision.wav

|                   |                                                                   |
|-------------------|-------------------------------------------------------------------|
| Name              | Clank Car Crash Collision                                         |
| Source            | https://pixabay.com/sound-effects/clank-car-crash-collision-6206/ |
| Original filename | clank-car-crash-collision-6206.wav                                |
| Uploaded by       | qubodup                                                           |

### bullets_collision.wav

|                   |                                                        |
|-------------------|--------------------------------------------------------|
| Name              | 080997 Bullet                                          |
| Source            | https://pixabay.com/sound-effects/080997-bullet-39735/ |
| Original filename | 080997_bullet-39735.wav                                |
| Uploaded by       | pixabay                                                |
