#!/bin/sh
java -cp ../lib/* MyFirstDroid.java 
