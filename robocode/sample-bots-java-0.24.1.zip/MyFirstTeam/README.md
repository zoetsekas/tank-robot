# MyFirstTeam

This directory represents a bot team consisting of:
- MyFirstLeader (there is one)
- MyFirstDroid (there are four of these)

The above bot directories must be available beside the MyFirstTeam.